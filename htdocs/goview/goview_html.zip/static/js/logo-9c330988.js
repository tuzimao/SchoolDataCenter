const o=""+new URL("../png/logo.png",import.meta.url).href;export{o as l};
