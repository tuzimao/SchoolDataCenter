const n=""+new URL("../png/noData.png",import.meta.url).href;export{n};
