"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_document";
exports.ids = ["pages/_document"];
exports.modules = {

/***/ "./src/@core/utils/create-emotion-cache.ts":
/*!*************************************************!*\
  !*** ./src/@core/utils/create-emotion-cache.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   createEmotionCache: () => (/* binding */ createEmotionCache)\n/* harmony export */ });\n/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/cache */ \"@emotion/cache\");\n/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_0__);\n\nconst createEmotionCache = ()=>{\n    return _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default()({\n        key: \"css\"\n    });\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvQGNvcmUvdXRpbHMvY3JlYXRlLWVtb3Rpb24tY2FjaGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQXdDO0FBRWpDLE1BQU1DLHFCQUFxQjtJQUNoQyxPQUFPRCxxREFBV0EsQ0FBQztRQUFFRSxLQUFLO0lBQU07QUFDbEMsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NjaG9vbGRhdGFjZW50ZXIvLi9zcmMvQGNvcmUvdXRpbHMvY3JlYXRlLWVtb3Rpb24tY2FjaGUudHM/NTNiOCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY3JlYXRlQ2FjaGUgZnJvbSAnQGVtb3Rpb24vY2FjaGUnXHJcblxyXG5leHBvcnQgY29uc3QgY3JlYXRlRW1vdGlvbkNhY2hlID0gKCkgPT4ge1xyXG4gIHJldHVybiBjcmVhdGVDYWNoZSh7IGtleTogJ2NzcycgfSlcclxufVxyXG4iXSwibmFtZXMiOlsiY3JlYXRlQ2FjaGUiLCJjcmVhdGVFbW90aW9uQ2FjaGUiLCJrZXkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/@core/utils/create-emotion-cache.ts\n");

/***/ }),

/***/ "./src/pages/_document.tsx":
/*!*********************************!*\
  !*** ./src/pages/_document.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _emotion_server_create_instance__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/server/create-instance */ \"@emotion/server/create-instance\");\n/* harmony import */ var _emotion_server_create_instance__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_server_create_instance__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var src_core_utils_create_emotion_cache__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/@core/utils/create-emotion-cache */ \"./src/@core/utils/create-emotion-cache.ts\");\n// ** React Import\n\n\n// ** Next Import\n\n// ** Emotion Imports\n\n// ** Utils Imports\n\nclass CustomDocument extends (next_document__WEBPACK_IMPORTED_MODULE_2___default()) {\n    render() {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_2__.Html, {\n            lang: \"en\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_2__.Head, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                            rel: \"stylesheet\",\n                            href: \"https://fonts.loli.net/css2?family=Inter:wght@300;400;500;600;700&display=swap\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                            lineNumber: 18,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                            rel: \"apple-touch-icon\",\n                            sizes: \"180x180\",\n                            href: \"/images/apple-touch-icon.png\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                            lineNumber: 19,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"link\", {\n                            rel: \"shortcut icon\",\n                            href: \"/images/favicon.png\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                            lineNumber: 20,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                    lineNumber: 17,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_2__.Main, {}, void 0, false, {\n                            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                            lineNumber: 23,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_2__.NextScript, {}, void 0, false, {\n                            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                            lineNumber: 24,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                    lineNumber: 22,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n            lineNumber: 16,\n            columnNumber: 7\n        }, this);\n    }\n}\nCustomDocument.getInitialProps = async (ctx)=>{\n    const originalRenderPage = ctx.renderPage;\n    const cache = (0,src_core_utils_create_emotion_cache__WEBPACK_IMPORTED_MODULE_4__.createEmotionCache)();\n    const { extractCriticalToChunks } = _emotion_server_create_instance__WEBPACK_IMPORTED_MODULE_3___default()(cache);\n    ctx.renderPage = ()=>originalRenderPage({\n            enhanceApp: (App)=>(props)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(App, {\n                        ...props,\n                        emotionCache: cache\n                    }, void 0, false, {\n                        fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n                        lineNumber: 40,\n                        columnNumber: 11\n                    }, undefined)\n        });\n    const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_2___default().getInitialProps(ctx);\n    const emotionStyles = extractCriticalToChunks(initialProps.html);\n    const emotionStyleTags = emotionStyles.styles.map((style)=>{\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"style\", {\n            dangerouslySetInnerHTML: {\n                __html: style.css\n            },\n            \"data-emotion\": `${style.key} ${style.ids.join(\" \")}`\n        }, style.key, false, {\n            fileName: \"D:\\\\SchoolDataCenter\\\\htdocs\\\\src\\\\pages\\\\_document.tsx\",\n            lineNumber: 51,\n            columnNumber: 7\n        }, undefined);\n    });\n    return {\n        ...initialProps,\n        styles: [\n            ...react__WEBPACK_IMPORTED_MODULE_1__.Children.toArray(initialProps.styles),\n            ...emotionStyleTags\n        ]\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomDocument);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2RvY3VtZW50LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUEsa0JBQWtCOztBQUNjO0FBRWhDLGlCQUFpQjtBQUNxRDtBQUV0RSxxQkFBcUI7QUFDNEM7QUFFakUsbUJBQW1CO0FBQ3NEO0FBRXpFLE1BQU1RLHVCQUF1QlAsc0RBQVFBO0lBQ25DUSxTQUFTO1FBQ1AscUJBQ0UsOERBQUNQLCtDQUFJQTtZQUFDUSxNQUFLOzs4QkFDVCw4REFBQ1AsK0NBQUlBOztzQ0FDSCw4REFBQ1E7NEJBQUtDLEtBQUk7NEJBQWFDLE1BQUs7Ozs7OztzQ0FDNUIsOERBQUNGOzRCQUFLQyxLQUFJOzRCQUFtQkUsT0FBTTs0QkFBVUQsTUFBSzs7Ozs7O3NDQUNsRCw4REFBQ0Y7NEJBQUtDLEtBQUk7NEJBQWdCQyxNQUFLOzs7Ozs7Ozs7Ozs7OEJBRWpDLDhEQUFDRTs7c0NBQ0MsOERBQUNYLCtDQUFJQTs7Ozs7c0NBQ0wsOERBQUNDLHFEQUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFJbkI7QUFDRjtBQUVBRyxlQUFlUSxlQUFlLEdBQUcsT0FBTUM7SUFDckMsTUFBTUMscUJBQXFCRCxJQUFJRSxVQUFVO0lBQ3pDLE1BQU1DLFFBQVFiLHVGQUFrQkE7SUFDaEMsTUFBTSxFQUFFYyx1QkFBdUIsRUFBRSxHQUFHZixzRUFBbUJBLENBQUNjO0lBRXhESCxJQUFJRSxVQUFVLEdBQUcsSUFDZkQsbUJBQW1CO1lBQ2pCSSxZQUFZQyxDQUFBQSxNQUFPQyxDQUFBQSxzQkFFZiw4REFBQ0Q7d0JBQ0UsR0FBR0MsS0FBSzt3QkFDVEMsY0FBY0w7Ozs7OztRQUd0QjtJQUVGLE1BQU1NLGVBQWUsTUFBTXpCLG9FQUF3QixDQUFDZ0I7SUFDcEQsTUFBTVUsZ0JBQWdCTix3QkFBd0JLLGFBQWFFLElBQUk7SUFDL0QsTUFBTUMsbUJBQW1CRixjQUFjRyxNQUFNLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQUE7UUFDaEQscUJBQ0UsOERBQUNBO1lBRUNDLHlCQUF5QjtnQkFBRUMsUUFBUUYsTUFBTUcsR0FBRztZQUFDO1lBQzdDQyxnQkFBYyxDQUFDLEVBQUVKLE1BQU1LLEdBQUcsQ0FBQyxDQUFDLEVBQUVMLE1BQU1NLEdBQUcsQ0FBQ0MsSUFBSSxDQUFDLEtBQUssQ0FBQztXQUY5Q1AsTUFBTUssR0FBRzs7Ozs7SUFLcEI7SUFFQSxPQUFPO1FBQ0wsR0FBR1gsWUFBWTtRQUNmSSxRQUFRO2VBQUk5QiwyQ0FBUUEsQ0FBQ3dDLE9BQU8sQ0FBQ2QsYUFBYUksTUFBTTtlQUFNRDtTQUFpQjtJQUN6RTtBQUNGO0FBRUEsaUVBQWVyQixjQUFjQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2Nob29sZGF0YWNlbnRlci8uL3NyYy9wYWdlcy9fZG9jdW1lbnQudHN4PzE4OGUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gKiogUmVhY3QgSW1wb3J0XHJcbmltcG9ydCB7IENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXHJcblxyXG4vLyAqKiBOZXh0IEltcG9ydFxyXG5pbXBvcnQgRG9jdW1lbnQsIHsgSHRtbCwgSGVhZCwgTWFpbiwgTmV4dFNjcmlwdCB9IGZyb20gJ25leHQvZG9jdW1lbnQnXHJcblxyXG4vLyAqKiBFbW90aW9uIEltcG9ydHNcclxuaW1wb3J0IGNyZWF0ZUVtb3Rpb25TZXJ2ZXIgZnJvbSAnQGVtb3Rpb24vc2VydmVyL2NyZWF0ZS1pbnN0YW5jZSdcclxuXHJcbi8vICoqIFV0aWxzIEltcG9ydHNcclxuaW1wb3J0IHsgY3JlYXRlRW1vdGlvbkNhY2hlIH0gZnJvbSAnc3JjL0Bjb3JlL3V0aWxzL2NyZWF0ZS1lbW90aW9uLWNhY2hlJ1xyXG5cclxuY2xhc3MgQ3VzdG9tRG9jdW1lbnQgZXh0ZW5kcyBEb2N1bWVudCB7XHJcbiAgcmVuZGVyKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEh0bWwgbGFuZz0nZW4nPlxyXG4gICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgPGxpbmsgcmVsPSdzdHlsZXNoZWV0JyBocmVmPSdodHRwczovL2ZvbnRzLmxvbGkubmV0L2NzczI/ZmFtaWx5PUludGVyOndnaHRAMzAwOzQwMDs1MDA7NjAwOzcwMCZkaXNwbGF5PXN3YXAnIC8+XHJcbiAgICAgICAgICA8bGluayByZWw9J2FwcGxlLXRvdWNoLWljb24nIHNpemVzPScxODB4MTgwJyBocmVmPScvaW1hZ2VzL2FwcGxlLXRvdWNoLWljb24ucG5nJyAvPlxyXG4gICAgICAgICAgPGxpbmsgcmVsPSdzaG9ydGN1dCBpY29uJyBocmVmPScvaW1hZ2VzL2Zhdmljb24ucG5nJyAvPlxyXG4gICAgICAgIDwvSGVhZD5cclxuICAgICAgICA8Ym9keT5cclxuICAgICAgICAgIDxNYWluIC8+XHJcbiAgICAgICAgICA8TmV4dFNjcmlwdCAvPlxyXG4gICAgICAgIDwvYm9keT5cclxuICAgICAgPC9IdG1sPlxyXG4gICAgKVxyXG4gIH1cclxufVxyXG5cclxuQ3VzdG9tRG9jdW1lbnQuZ2V0SW5pdGlhbFByb3BzID0gYXN5bmMgY3R4ID0+IHtcclxuICBjb25zdCBvcmlnaW5hbFJlbmRlclBhZ2UgPSBjdHgucmVuZGVyUGFnZVxyXG4gIGNvbnN0IGNhY2hlID0gY3JlYXRlRW1vdGlvbkNhY2hlKClcclxuICBjb25zdCB7IGV4dHJhY3RDcml0aWNhbFRvQ2h1bmtzIH0gPSBjcmVhdGVFbW90aW9uU2VydmVyKGNhY2hlKVxyXG5cclxuICBjdHgucmVuZGVyUGFnZSA9ICgpID0+XHJcbiAgICBvcmlnaW5hbFJlbmRlclBhZ2Uoe1xyXG4gICAgICBlbmhhbmNlQXBwOiBBcHAgPT4gcHJvcHMgPT5cclxuICAgICAgICAoXHJcbiAgICAgICAgICA8QXBwXHJcbiAgICAgICAgICAgIHsuLi5wcm9wc30gLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgICAgICBlbW90aW9uQ2FjaGU9e2NhY2hlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApXHJcbiAgICB9KVxyXG5cclxuICBjb25zdCBpbml0aWFsUHJvcHMgPSBhd2FpdCBEb2N1bWVudC5nZXRJbml0aWFsUHJvcHMoY3R4KVxyXG4gIGNvbnN0IGVtb3Rpb25TdHlsZXMgPSBleHRyYWN0Q3JpdGljYWxUb0NodW5rcyhpbml0aWFsUHJvcHMuaHRtbClcclxuICBjb25zdCBlbW90aW9uU3R5bGVUYWdzID0gZW1vdGlvblN0eWxlcy5zdHlsZXMubWFwKHN0eWxlID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzdHlsZVxyXG4gICAgICAgIGtleT17c3R5bGUua2V5fVxyXG4gICAgICAgIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogc3R5bGUuY3NzIH19XHJcbiAgICAgICAgZGF0YS1lbW90aW9uPXtgJHtzdHlsZS5rZXl9ICR7c3R5bGUuaWRzLmpvaW4oJyAnKX1gfVxyXG4gICAgICAvPlxyXG4gICAgKVxyXG4gIH0pXHJcblxyXG4gIHJldHVybiB7XHJcbiAgICAuLi5pbml0aWFsUHJvcHMsXHJcbiAgICBzdHlsZXM6IFsuLi5DaGlsZHJlbi50b0FycmF5KGluaXRpYWxQcm9wcy5zdHlsZXMpLCAuLi5lbW90aW9uU3R5bGVUYWdzXVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tRG9jdW1lbnRcclxuIl0sIm5hbWVzIjpbIkNoaWxkcmVuIiwiRG9jdW1lbnQiLCJIdG1sIiwiSGVhZCIsIk1haW4iLCJOZXh0U2NyaXB0IiwiY3JlYXRlRW1vdGlvblNlcnZlciIsImNyZWF0ZUVtb3Rpb25DYWNoZSIsIkN1c3RvbURvY3VtZW50IiwicmVuZGVyIiwibGFuZyIsImxpbmsiLCJyZWwiLCJocmVmIiwic2l6ZXMiLCJib2R5IiwiZ2V0SW5pdGlhbFByb3BzIiwiY3R4Iiwib3JpZ2luYWxSZW5kZXJQYWdlIiwicmVuZGVyUGFnZSIsImNhY2hlIiwiZXh0cmFjdENyaXRpY2FsVG9DaHVua3MiLCJlbmhhbmNlQXBwIiwiQXBwIiwicHJvcHMiLCJlbW90aW9uQ2FjaGUiLCJpbml0aWFsUHJvcHMiLCJlbW90aW9uU3R5bGVzIiwiaHRtbCIsImVtb3Rpb25TdHlsZVRhZ3MiLCJzdHlsZXMiLCJtYXAiLCJzdHlsZSIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiX19odG1sIiwiY3NzIiwiZGF0YS1lbW90aW9uIiwia2V5IiwiaWRzIiwiam9pbiIsInRvQXJyYXkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_document.tsx\n");

/***/ }),

/***/ "@emotion/cache":
/*!*********************************!*\
  !*** external "@emotion/cache" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@emotion/cache");

/***/ }),

/***/ "@emotion/server/create-instance":
/*!**************************************************!*\
  !*** external "@emotion/server/create-instance" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("@emotion/server/create-instance");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./src/pages/_document.tsx")));
module.exports = __webpack_exports__;

})();