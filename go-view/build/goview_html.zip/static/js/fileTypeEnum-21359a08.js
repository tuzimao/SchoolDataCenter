var g=(a=>(a.TXT="text/plain",a.JSON="application/json",a.PNG="image/png",a.JPEG="image/jpeg",a.GIF="image/gif",a))(g||{});export{g as F};
