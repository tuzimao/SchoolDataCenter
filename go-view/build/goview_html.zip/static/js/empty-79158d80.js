const e="FeatureCollection",t=[],o={type:e,features:t};export{o as default,t as features,e as type};
